# Beyond errors Hugo Theme

A quiet, responsive Hugo theme with dark and warm light modes, archive and tag pages, article navigation, RSS, accessible Markdown callouts, code labels, Mermaid diagrams, math, and image captions.

## Setup

Copy `themes/linjian` into your Hugo site and set the theme in `hugo.toml`:

```toml
theme = "linjian"
title = "Beyond errors"
locale = "en-US"

[pagination]
  pagerSize = 10

[taxonomies]
  tag = "tags"

[params]
  description = "Notes on code, systems, and the small details in between."
  author = "err-0x000000EF"
```

Place posts in `content/posts/`. Use `title`, `date`, `tags`, and optional `description` front matter fields.

## Run and build

```sh
hugo server
hugo --minify
```

The included sample site uses Hugo pagination with ten posts per page. The theme has no Node package or external Hugo module dependency. Mermaid and KaTeX are loaded from jsDelivr only on pages that need those renderers.
