# Beyond errors — Hugo + private GitHub Issues

This starter turns selected Issues in one private GitHub repository into public posts on a Hugo site. The site template and workflow live in a public GitHub Pages repository; the Issue source repository remains private.

> **Publishing is intentional:** an open Issue labeled `publish` becomes a public web page. Anyone can read the rendered post. Do not apply that label to content that must remain private.

## What this starter does

- Uses the Beyond errors Hugo theme, with English site UI and the Markdown showcase kept as a draft.
- Reads open Issues from one configured private repository each day at 12:00 UTC.
- Publishes only Issues labeled `publish`; labels like `tag:hugo` become public tags.
- Uses the Issue creation time as the post date.
- Removes a post on the next successful sync if its Issue is closed or `publish` is removed.
- Writes fetched Markdown only under the Actions runner's temporary directory, then deletes it. Hugo's diagnostic output is also captured in a temporary file and suppressed.
- Uploads only the rendered website to GitHub Pages. The private source URL, Issue number, token, raw Markdown files, and Markdown snapshot are not written into the public repository or Pages artifact.
- Keeps a keyed HMAC fingerprint in the public repository's Actions cache so unchanged Issues do not trigger a rebuild. The cache does not contain post text.

GitHub Actions scheduled jobs are best-effort. The workflow requests 12:00 UTC, but GitHub can start a scheduled run late or drop it during high load. Use manual `Run workflow` for an immediate update.

## Before starting

You need one GitHub account. The account name in this guide is `err-0x000000EF` (GitHub treats account names without case sensitivity). There will be two repositories:

| Repository | Visibility | Purpose |
| --- | --- | --- |
| Private source repository, for example `my-private-notes` | Private | You write Issues here. Keep yourself as the only collaborator. |
| `err-0x000000ef.github.io` | Public | Contains this Hugo template and its Actions workflow; serves the public site. |

The template files belong at the **root** of the public Pages repository. Do not put the whole extracted folder inside another folder.

## Step 1 — Create or sign in to GitHub

1. Open [github.com](https://github.com) and create an account, or sign in to the account whose username is `err-0x000000EF`.
2. Confirm your email address if GitHub asks.

## Step 2 — Create your private Issue notebook

1. In GitHub, choose **New repository**.
2. Give it a name such as `my-private-notes`.
3. Select **Private** and create the repository.
4. In **Settings → General → Features**, make sure **Issues** is enabled.
5. Do not add collaborators. Keep the repo private. Create Issues as your notes.

You can use Issue title as the post title and Issue body as the article. The first publication uses the Issue's creation date. To change a published article, edit its Issue; the next sync will update the rendered post.

## Step 3 — Create the public website repository

1. Choose **New repository**.
2. Name it exactly `err-0x000000ef.github.io` (replace that name if your actual account username differs).
3. Select **Public**. You do not need to initialize it with a README.
4. Create it.

For a GitHub Pages user site, the repository name must match `ACCOUNT.github.io`. Its URL will be `https://ACCOUNT.github.io/`.

## Step 4 — Install the template without GitHub Desktop

You can do this entirely in your browser. The one-time installer workflow is provided separately as `unpack-template-once.yml`.

1. Keep the new public repository empty (do not initialize it with a README).
2. In the repository choose **Add file → Create new file**. For the filename, enter `.github/workflows/unpack-template.yml`.
3. Open the separately provided `unpack-template-once.yml` on your computer, copy its full contents, and paste them into GitHub's editor. Commit the new workflow to the `main` branch.
4. On the repository page choose **Add file → Upload files** and upload `beyond-errors-hugo-issue-blog.zip` to the repository root. Commit that upload.
5. Open **Actions → Install Beyond errors Hugo template → Run workflow → Run workflow**.
6. Wait for the green check. The installer extracts the package into the repository root, commits the Hugo theme and publishing workflow, then deletes the uploaded ZIP and its own one-time workflow.

Afterward, the repository root should contain `hugo.toml`, `content`, `themes`, and `.github/workflows/publish-private-issues.yml`. The public repo contains the theme and workflow, not the private Issues or their original Markdown files.

## Step 5 — Make a read-only key for the private repository

The public workflow needs permission to read Issues in your private notebook. It does not need permission to write to that repository.

1. In GitHub open **Settings → Developer settings → Personal access tokens → Fine-grained tokens**.
2. Choose **Generate new token**. Give it a recognizable name like `Beyond errors issue reader` and set an expiry date you can remember.
3. Under **Resource owner**, select your account.
4. Under **Repository access**, choose **Only select repositories**, then select only your private Issue notebook.
5. Under **Repository permissions**, set **Issues** to **Read-only**. Leave all write permissions unavailable. Metadata read access is normally selected automatically by GitHub.
6. Generate the token and copy it once. GitHub will not show the full value again.

Do not paste the token into an Issue, workflow file, README, or chat. You will store it as an Actions secret in the next step. When it expires, create a replacement token and update that one secret.

## Step 6 — Add the workflow's private settings

In the public `err-0x000000ef.github.io` repository open **Settings → Secrets and variables → Actions**.

Create these **Repository secrets**:

| Secret name | Value |
| --- | --- |
| `ISSUE_SOURCE_OWNER` | Your account name, e.g. `err-0x000000EF` |
| `ISSUE_SOURCE_REPO` | The private repository name, e.g. `my-private-notes` |
| `ISSUE_SOURCE_TOKEN` | The fine-grained read-only token from Step 5 |
| `SYNC_HMAC_KEY` | A random secret used to make a private, non-reversible change fingerprint |

Generate `SYNC_HMAC_KEY` on your computer with `openssl rand -hex 32` (Linux/macOS). Copy the output into the secret form. If you do not have OpenSSL, use a password manager to generate a random value of at least 64 hexadecimal characters.

Then create this **Repository variable** (not secret):

| Variable name | Value |
| --- | --- |
| `SITE_BASE_URL` | `https://err-0x000000ef.github.io/` |

Use your actual account spelling in the URL. Keep the trailing slash. Do not put the PAT or HMAC key in a variable; variables are not secret.

## Step 7 — Turn on GitHub Pages

1. In the public site repository open **Settings → Pages**.
2. Under **Build and deployment**, set **Source** to **GitHub Actions**.
3. Save if GitHub shows a Save button.

## Step 8 — Publish your first Issue

1. In the private notebook create an Issue with an English title and Markdown body.
2. Add a label named exactly `publish`. Create the label if it does not exist.
3. Add any public tags as labels prefixed with `tag:`, for example `tag:hugo`, `tag:notes`, or `tag:systems`.
4. Do not use private editorial labels as `tag:` labels; every `tag:` label is displayed publicly on the site.
5. In the public website repository open **Actions → Publish private issues with Hugo → Run workflow → Run workflow**.
6. Open the run and wait for the green check. If it fails, the workflow intentionally hides Issue text and detailed build logs. Check that the secret names, token access, Pages settings, and `SITE_BASE_URL` match this guide.

After a successful run, visit `https://err-0x000000ef.github.io/`. The first publish may take a few minutes to become available.

## Everyday use

- **Publish:** open Issue + `publish` label.
- **Add/update a tag:** add, remove, or rename a `tag:...` label.
- **Edit:** edit the Issue title or body; the daily workflow republishes it.
- **Unpublish:** remove `publish` or close the Issue; the next successful sync removes it from the site.
- **Run now:** use the Actions tab and select **Run workflow**.
- **Daily run:** the workflow asks GitHub to start at 12:00 UTC. GitHub's schedule is not a guaranteed clock, so allow for delays.

## Privacy boundaries in plain language

The public repo reveals the Hugo template and workflow code, but not the secret values. The workflow only requests read access to Issues in the one private repo you selected. It does not print Issue bodies, titles, private URLs, token values, or API error details to logs. It does not commit fetched Markdown. The Markdown files exist briefly on the temporary GitHub runner so Hugo can render them, then the workflow removes them. Only the resulting public HTML, CSS, JavaScript, and site assets are uploaded to Pages.

The published article itself is public, including any text or images you placed in its Issue body. This workflow protects the original source file and private repository details; it cannot make published article content private.

## Markdown and MDX notes

Hugo renders Markdown and the extensions configured in `hugo.toml`, including tables, task lists, definition lists, footnotes, strikethrough, subscript/superscript, mark, and raw HTML used by the theme. The theme styles code blocks, alerts, Mermaid diagrams, math, and image captions. Its browser script also turns the specific static demo tags in the showcase (`Card`, `Tabs`, `Badge`, `Progress`, and related examples) into styled HTML interactions.

Hugo is not an MDX/React runtime. JSX components that expect JavaScript/React execution (for example arbitrary `<Component prop={...} />`, interactive forms, or React charts) cannot execute just because they are in an Issue. For safe static content use Markdown, HTML supported by Hugo, Mermaid fences, math, or Hugo shortcodes/templates. Do not treat this as full, unrestricted support for every third-party MDX component syntax.

## Files in this template

- `hugo.toml` — Hugo site configuration.
- `themes/linjian/` — Beyond errors theme: layouts, styles, scripts, and Markdown render hooks.
- `content/about.md` — English About page.
- `content/posts/markdown-mdx-showcase.md` — full feature showcase, kept as a draft so it does not appear publicly by default.
- `.github/workflows/publish-private-issues.yml` — scheduled/manual build and deploy workflow.
- `.github/scripts/sync-private-issues.mjs` — private Issue fetcher and temporary Markdown generator.

## Troubleshooting quick checks

- A workflow says it cannot read Issues: verify the fine-grained token selected the correct private repository and has **Issues: Read-only**; update `ISSUE_SOURCE_TOKEN` if the token expired.
- No article appears: check that the Issue is open and has the exact `publish` label, then run the workflow manually.
- Tags do not appear: labels must start with `tag:`.
- Site URL is a 404: confirm the public repo has the exact `ACCOUNT.github.io` name, Pages source is **GitHub Actions**, and `SITE_BASE_URL` uses the matching URL with a trailing slash.
- A workflow is green but the latest edit is missing: check whether the schedule has not run yet; use **Run workflow** to sync immediately.
